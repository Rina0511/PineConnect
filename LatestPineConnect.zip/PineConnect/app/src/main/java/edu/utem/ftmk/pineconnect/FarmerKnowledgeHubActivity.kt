package edu.utem.ftmk.pineconnect

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class FarmerKnowledgeHubActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_farmer_knowledge_hub)

        // TODO: Implement logic to display educational articles, videos, or PDFs on pineapple farming.
        // This could use a RecyclerView for articles categorized by topic (e.g., Pest Control, Harvesting).
    }
}