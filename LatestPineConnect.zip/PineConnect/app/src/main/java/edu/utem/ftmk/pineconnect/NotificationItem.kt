package edu.utem.ftmk.pineconnect

data class NotificationItem(
    val title: String,
    val message: String,
    val date: String
)

