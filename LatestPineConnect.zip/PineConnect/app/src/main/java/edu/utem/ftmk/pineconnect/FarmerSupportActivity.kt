package edu.utem.ftmk.pineconnect

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class FarmerSupportActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_farmer_support)

        // TODO: Implement logic for support contact (e.g., initiating a call, sending an email, or submitting a support ticket).
    }
}