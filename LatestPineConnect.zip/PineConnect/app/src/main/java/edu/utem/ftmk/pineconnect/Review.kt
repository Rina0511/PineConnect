package edu.utem.ftmk.pineconnect

data class Review(
    val user: String = "",
    val rating: Int = 0,
    val comment: String = ""
)

